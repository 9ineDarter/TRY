# 🎯 InfoDarts - Versión Mejorada

## 📋 Resumen de Mejoras

Tu página web de dardos ha sido completamente renovada con las siguientes mejoras:

### 🎨 Diseño y Estética
- ✅ **Sistema de diseño moderno** con variables CSS organizadas
- ✅ **Tema oscuro/claro** con transiciones suaves
- ✅ **Tipografía mejorada** usando Poppins e Inter
- ✅ **Paleta de colores profesional** con gradientes
- ✅ **Animaciones sutiles** en hover y transiciones
- ✅ **Iconos SVG** para redes sociales y navegación

### 📱 Responsive Design
- ✅ **Mobile-first approach** optimizado para móviles
- ✅ **Grid adaptativo** para el calendario
- ✅ **Menú hamburguesa mejorado** con animaciones
- ✅ **Cards responsivas** que se adaptan a cualquier pantalla
- ✅ **Sidebar fijo en desktop** para mejor navegación

### 🚀 Funcionalidades
- ✅ **Navegación por secciones** sin recargar la página
- ✅ **Toggle de tema** persistente en localStorage
- ✅ **Overlay para menú móvil** con blur effect
- ✅ **Estados de carga** para contenido dinámico
- ✅ **Manejo de errores** mejorado
- ✅ **Accesibilidad** con aria-labels y navegación por teclado

### 💅 Experiencia de Usuario
- ✅ **Calendario visual mejorado** con badges de tipos de torneos
- ✅ **Cards de artículos** con efectos hover y imágenes optimizadas
- ✅ **Tabla de ranking** con estilos alternados y sticky header
- ✅ **Footer completo** con enlaces a redes sociales
- ✅ **Smooth scrolling** entre secciones
- ✅ **Loading spinners** mientras carga el contenido

### 🔧 Código
- ✅ **JavaScript modular** mejor organizado
- ✅ **CSS con variables** para fácil personalización
- ✅ **Comentarios detallados** en todo el código
- ✅ **Mejores prácticas** de HTML5 semántico
- ✅ **Performance optimizada** con lazy loading de imágenes

## 🎯 Características del Tema Oscuro/Claro

El sitio ahora incluye un sistema de temas que se puede cambiar con los botones de luna/sol:

- **Tema claro**: Colores suaves y fondo blanco para mejor lectura diurna
- **Tema oscuro**: Colores oscuros que reducen la fatiga visual nocturna
- **Persistencia**: El tema seleccionado se guarda en localStorage
- **Transiciones suaves**: Cambio fluido entre temas

## 📁 Estructura de Archivos

```
infodarts/
├── index.html              # Página principal (MEJORADA)
├── styles.css              # Estilos principales (MEJORADA)
├── script.js               # JavaScript principal (MEJORADO)
├── articles.json           # Datos de artículos y rutinas
├── articles/               # Carpeta con imágenes y documentos
│   ├── imagen 1.jpg
│   ├── imagen2.jpg
│   ├── imagen3.jpg
│   └── Entrevista 1.docx
├── scripts/                # Librerías externas
│   └── xlsx.full.min.js
├── ranking_dardos_pdc_desde.xlsx
├── articulo.html           # Página de artículo individual
├── rutina.html             # Página de rutina individual
├── predict.html            # Página de predicciones
└── ranking.html            # Página de ranking
```

## 🚀 Cómo Usar

### Instalación
1. Descarga todos los archivos
2. Mantén la estructura de carpetas intacta
3. Abre `index.html` en tu navegador

### Despliegue
Puedes subir estos archivos a:
- **Vercel** (recomendado)
- **Netlify**
- **GitHub Pages**
- Cualquier hosting web

### Personalización

#### Cambiar Colores
Edita las variables en `styles.css` (líneas 1-40):
```css
:root {
  --accent-primary: #2563EB;  /* Color principal */
  --accent-secondary: #3B82F6; /* Color secundario */
  /* ... más variables */
}
```

#### Añadir Torneos
Edita el array `torneos` en `script.js` (líneas 9-15):
```javascript
const torneos = [
  { 
    titulo: "Nombre del torneo", 
    tipo: "pdc",  // o "wdf"
    fecha: "2025-09-05", 
    hora: "13:00", 
    enlace: "https://..." 
  }
];
```

#### Añadir Artículos
Edita el archivo `articles.json`:
```json
{
  "articles": [
    {
      "title": "Título del artículo",
      "summary": "Resumen breve",
      "image": "articles/imagen.jpg",
      "docx": "articles/documento.docx"
    }
  ]
}
```

## 🎨 Paleta de Colores

### Tema Claro
- **Primario**: #2563EB (Azul)
- **Secundario**: #3B82F6 (Azul claro)
- **Fondo**: #F8F9FB
- **Texto**: #1A1D29

### Tema Oscuro
- **Primario**: #3B82F6 (Azul brillante)
- **Secundario**: #60A5FA (Azul cielo)
- **Fondo**: #0F1419
- **Texto**: #E8EAED

## ⌨️ Atajos de Teclado

- **Escape**: Cierra el menú lateral (en móvil)
- **Navegación con Tab**: Accesible por teclado

## 🔧 Funcionalidades Técnicas

### LocalStorage
El sitio usa localStorage para:
- Tema seleccionado (`theme`)
- Consentimiento de anuncios (`ads_consent`)

### Responsive Breakpoints
- **Móvil**: < 640px
- **Tablet**: 640px - 1024px
- **Desktop**: > 1024px

## 📊 Compatibilidad

- ✅ Chrome/Edge (moderno)
- ✅ Firefox (moderno)
- ✅ Safari (moderno)
- ✅ Opera
- ✅ Mobile browsers

## 🐛 Solución de Problemas

### El calendario no se muestra
- Verifica que `script.js` esté cargado correctamente
- Revisa la consola del navegador (F12) por errores

### Las imágenes no cargan
- Verifica que la carpeta `articles/` exista
- Comprueba las rutas en `articles.json`

### El tema no cambia
- Limpia el localStorage: `localStorage.clear()`
- Recarga la página (Ctrl + F5)

### El ranking no aparece
- Verifica que `ranking_dardos_pdc_desde.xlsx` exista
- Comprueba que `scripts/xlsx.full.min.js` esté presente

## 📝 Próximas Mejoras Sugeridas

1. **Sistema de búsqueda** de artículos y rutinas
2. **Filtros** para el calendario (solo PDC, solo WDF)
3. **Compartir en redes sociales** desde artículos
4. **Newsletter** para suscripción
5. **Sistema de comentarios** en artículos
6. **PWA** (Progressive Web App) para instalación móvil
7. **Notificaciones** de próximos torneos
8. **Multi-idioma** (catalán, inglés)

## 🤝 Créditos

- **Diseño y desarrollo**: Versión mejorada
- **Original**: InfoDarts
- **Fuentes**: Google Fonts (Poppins, Inter)
- **Iconos**: SVG personalizados

## 📧 Contacto

Para consultas o sugerencias:
- Email: 9inedarter@gmail.com
- Instagram: @9inedarter
- X (Twitter): @9inedarter

---

**¡Hecho con ❤️ para la comunidad de dardos!** 🎯
